from bs4 import BeautifulSoup
from typing import List, Dict, Any, Optional
from utils import css_color_to_rgb, contrast_ratio, build_css_selector, get_inline_style_value

# ---------------------- Rule helpers ----------------------

GENERIC_LINK_TEXT = {
    "click here", "here", "read more", "learn more", "more", "details", "link"
}

def _code_snippet(el) -> str:
    # Trim and collapse whitespace
    html = str(el)
    return " ".join(html.strip().split())[:500]

def _make_violation(ruleId: str, message: str, el) -> Dict[str, Any]:
    selector = build_css_selector(el)
    name = el.name if el and el.name else "document"
    return {
        "ruleId": ruleId,
        "message": message,
        "element": name,
        "selector": selector,
        "codeSnippet": _code_snippet(el) if el else ""
    }

# ---------------------- Rules ----------------------

def check_doc_lang_missing(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    html_el = soup.find("html")
    if not html_el:
        # If not present at all, flag it
        return [{
            "ruleId": "DOC_LANG_MISSING",
            "message": "Document is missing <html> element with a lang attribute.",
            "element": "document",
            "selector": "html",
            "codeSnippet": ""
        }]
    lang = html_el.get("lang", "").strip()
    if not lang:
        return [_make_violation("DOC_LANG_MISSING", "The <html> element must have a valid lang attribute.", html_el)]
    return []

def check_doc_title_missing(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    title_el = soup.find("title")
    if not title_el or not title_el.get_text(strip=True):
        head_el = soup.find("head")
        return [_make_violation("DOC_TITLE_MISSING", "Every page must have a non-empty <title> tag.", head_el if head_el else soup)]
    return []

def _is_large_text(el) -> bool:
    # Approximation: treat h1 and h2 as large; also font-size >= 24px is large.
    if not getattr(el, "name", None):
        return False
    if el.name in ("h1", "h2"):
        return True
    fs = get_inline_style_value(el, "font-size")
    if fs and fs.endswith("px"):
        try:
            px = float(fs[:-2])
            if px >= 24.0:
                return True
        except:
            pass
    return False

def _effective_text_color(el) -> Optional[tuple]:
    # Only look at inline style color; default to black if not set
    color_val = get_inline_style_value(el, "color")
    if color_val:
        rgb = css_color_to_rgb(color_val)
        if rgb:
            return rgb
    return (0, 0, 0)  # default black

def _effective_bg_color(el) -> Optional[tuple]:
    # Only look at inline style background-color; default to white if not set
    bg = get_inline_style_value(el, "background-color")
    if bg:
        rgb = css_color_to_rgb(bg)
        if rgb:
            return rgb
    return (255, 255, 255)  # default white

def check_color_contrast(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    violations = []
    # Consider headings, paragraphs, links, spans, divs with text
    candidates = soup.find_all(True)
    for el in candidates:
        # Must have some text content
        if not el.get_text(strip=True):
            continue
        fg = _effective_text_color(el)
        bg = _effective_bg_color(el)
        if not fg or not bg:
            continue
        ratio = contrast_ratio(fg, bg)
        threshold = 3.0 if _is_large_text(el) else 4.5
        if ratio < threshold:
            msg = f"Low contrast ratio: {ratio:.2f}. Minimum expected is {threshold:.1f}."
            violations.append(_make_violation("COLOR_CONTRAST", msg, el))
    return violations

def check_img_alt(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    violations = []
    for img in soup.find_all("img"):
        alt = img.get("alt")
        if alt is None or alt.strip() == "":
            violations.append(_make_violation("IMG_ALT_MISSING", "All <img> must have a non-empty alt attribute.", img))
        elif len(alt) > 120:
            violations.append(_make_violation("IMG_ALT_LENGTH", "Image alt text should not exceed 120 characters.", img))
    return violations

def check_link_generic_text(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    violations = []
    for a in soup.find_all("a"):
        text = a.get_text(" ", strip=True).lower()
        norm = " ".join(text.split())
        if norm in GENERIC_LINK_TEXT or norm.endswith(" click here") or norm == "click":
            violations.append(_make_violation("LINK_GENERIC_TEXT", "Link text should be descriptive. Avoid generic phrases.", a))
    return violations

def check_heading_order(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    violations = []
    headings = soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"])
    last_level = 0
    for h in headings:
        level = int(h.name[1])
        if last_level and level > last_level + 1:
            violations.append(_make_violation("HEADING_ORDER", f"Heading level skipped from h{last_level} to h{level}.", h))
        last_level = level
    return violations

def check_heading_multiple_h1(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    h1s = soup.find_all("h1")
    if len(h1s) > 1:
        # Flag every extra h1 after the first
        return [_make_violation("HEADING_MULTIPLE_H1", "There must be only one <h1> per page.", h) for h in h1s[1:]]
    return []

# ---------------------- Main Analyzer ----------------------

def analyze_html(html: str) -> List[Dict[str, Any]]:
    soup = BeautifulSoup(html, "lxml")
    violations: List[Dict[str, Any]] = []
    # Document-level
    violations.extend(check_doc_lang_missing(soup))
    violations.extend(check_doc_title_missing(soup))
    # Content-level
    violations.extend(check_color_contrast(soup))
    violations.extend(check_img_alt(soup))
    violations.extend(check_link_generic_text(soup))
    violations.extend(check_heading_order(soup))
    violations.extend(check_heading_multiple_h1(soup))
    return violations
