from typing import Optional, Tuple
import re
from bs4 import Tag

# Minimal CSS color name mapping (extend as needed)
NAMED_COLORS = {
    "black": (0, 0, 0),
    "white": (255, 255, 255),
    "red": (255, 0, 0),
    "green": (0, 128, 0),
    "lightgreen": (144, 238, 144),
    "blue": (0, 0, 255),
    "yellow": (255, 255, 0),
    "gray": (128, 128, 128),
    "grey": (128, 128, 128),
    "transparent": None,  # treat as None
}

HEX_RE = re.compile(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})\b")
RGB_RE = re.compile(r"rgb\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)")

def css_color_to_rgb(value: str) -> Optional[Tuple[int, int, int]]:
    if not value:
        return None
    v = value.strip().lower()
    if v in NAMED_COLORS:
        return NAMED_COLORS[v]
    m = HEX_RE.search(v)
    if m:
        hexv = m.group(1)
        if len(hexv) == 3:
            r = int(hexv[0]*2, 16)
            g = int(hexv[1]*2, 16)
            b = int(hexv[2]*2, 16)
            return (r, g, b)
        else:
            r = int(hexv[0:2], 16)
            g = int(hexv[2:4], 16)
            b = int(hexv[4:6], 16)
            return (r, g, b)
    m = RGB_RE.search(v)
    if m:
        r, g, b = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
        return (max(0, min(r, 255)), max(0, min(g, 255)), max(0, min(b, 255)))
    return None

def relative_luminance(rgb: Tuple[int, int, int]) -> float:
    def channel(c: int) -> float:
        cs = c / 255.0
        return cs / 12.92 if cs <= 0.04045 else ((cs + 0.055) / 1.055) ** 2.4
    r, g, b = rgb
    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)

def contrast_ratio(fg: Tuple[int, int, int], bg: Tuple[int, int, int]) -> float:
    L1 = relative_luminance(fg)
    L2 = relative_luminance(bg)
    lighter = max(L1, L2)
    darker = min(L1, L2)
    return (lighter + 0.05) / (darker + 0.05)

def get_inline_style_value(el: Tag, prop: str) -> Optional[str]:
    style = el.get("style")
    if not style:
        return None
    # crude parse of inline style
    try:
        for part in style.split(";"):
            if not part.strip():
                continue
            if ":" not in part:
                continue
            k, v = part.split(":", 1)
            if k.strip().lower() == prop.lower():
                return v.strip()
        return None
    except Exception:
        return None

def build_css_selector(el: Tag) -> str:
    # Build a simple css selector like html > body > div:nth-of-type(2) > p:nth-of-type(1)
    parts = []
    cur = el
    while cur and isinstance(cur, Tag):
        parent = cur.parent if hasattr(cur, "parent") else None
        if not parent or not isinstance(parent, Tag):
            parts.append(cur.name)
            break
        # find nth-of-type among siblings of same tag
        index = 1
        for sib in parent.find_all(cur.name, recursive=False):
            if sib is cur:
                break
            index += 1
        parts.append(f"{cur.name}:nth-of-type({index})")
        cur = parent
    parts.reverse()
    return " > ".join(parts)
