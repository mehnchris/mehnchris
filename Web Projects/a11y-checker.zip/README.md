# HTML Accessibility Checker

A full‑stack app to quickly check an HTML document for common accessibility issues (a11y).  
Frontend: React (Vite). Backend: FastAPI (Python).

## Features
- Paste or upload HTML and run an accessibility scan
- Violations list with rule id, message, element, selector and code snippet
- Click a violation to highlight the offending element in a live preview, and auto‑copy the CSS selector
- Implements the required rules:
  - **DOC_LANG_MISSING** – `<html>` must have `lang`
  - **DOC_TITLE_MISSING** – page must have non‑empty `<title>`
  - **COLOR_CONTRAST** – WCAG contrast check (≥4.5:1 normal, ≥3.0:1 large)
  - **IMG_ALT_MISSING** – images must have non‑empty `alt`
  - **IMG_ALT_LENGTH** – `alt` ≤ 120 chars
  - **LINK_GENERIC_TEXT** – avoid generic link text like “click here”
  - **HEADING_ORDER** – do not skip heading levels
  - **HEADING_MULTIPLE_H1** – only one `<h1>` per page

---

## Getting Started (Visual Studio or Terminal)

### 1) Backend (FastAPI)
```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
The API will run at `http://localhost:8000`  
Health check: `GET /health` → `{"status":"ok"}`

**Analyze endpoint**
```
POST /api/analyze
Content-Type: application/json
{ "html": "<!doctype html> ... </html>" }
```
Response:
```json
{
  "violations": [
    {
      "ruleId": "COLOR_CONTRAST",
      "message": "Low contrast ratio: 1.98. Minimum expected is 3.0.",
      "element": "h1",
      "selector": "html > body:nth-of-type(1) > h1:nth-of-type(1)",
      "codeSnippet": "<h1 style=\"...\">Welcome</h1>"
    }
  ]
}
```

### 2) Frontend (React + Vite)
```bash
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`. If your backend runs on a different host/port, update the **API** field in the UI.

**Visual Studio users:** You can open this folder as a Node/React project. Alternatively, add both projects to a single VS solution and run them concurrently (backend first).

---

## Code Map

```
/backend
  ├─ main.py            # FastAPI app & /api/analyze
  ├─ a11y_rules.py      # All rule checks
  ├─ utils.py           # Color parsing, contrast calc, selector builder
  ├─ requirements.txt
  └─ test_sample.html

/frontend
  ├─ index.html
  ├─ vite.config.js
  ├─ package.json
  └─ src
     ├─ App.jsx         # UI, file upload, list + preview + highlight
     ├─ api.js          # fetch wrapper for /api/analyze
     ├─ main.jsx
     └─ styles.css
```

---

## Implementation Notes

### Contrast Calculation
- Converts inline CSS `color` and `background-color` to RGB
- Supports hex (`#rgb`, `#rrggbb`), `rgb(r,g,b)`, and a minimal set of named colors
- Defaults: text `black`, background `white` when not specified inline
- Large text threshold is applied for `<h1>`, `<h2>` or `font-size >= 24px`

### Headings
- **HEADING_ORDER** flags jumps like `h2 → h4`
- **HEADING_MULTIPLE_H1** flags every extra `<h1>` beyond the first

### Links
- **LINK_GENERIC_TEXT** flags anchors whose normalized text is generic
  (`"click here"`, `"here"`, `"read more"`, etc.)

### Images
- **IMG_ALT_MISSING** requires `alt` and non‑empty
- **IMG_ALT_LENGTH** warns when `alt` length exceeds 120 characters

---

## Innovative Features

1. **Live inline highlighting via `postMessage`**  
   Click any violation to highlight the offending element inside a sandboxed preview iframe and scroll it into view. See `frontend/src/App.jsx` where the parent posts a `HIGHLIGHT` message and the iframe script applies the `.a11y-highlight` class.

2. **CSS Selector Copy-on-Click**  
   When you click a result, its CSS selector is copied to the clipboard to aid debugging and automated tests. See `onClickItem` in `App.jsx`.

3. **Local Persistence**  
   The pasted/uploaded HTML is persisted to `localStorage`, so you can refresh the page without losing context. See `useEffect` in `App.jsx`.

4. **Clear, Extensible Rule Engine**  
   Rules are modularized in `backend/a11y_rules.py` and utilities in `backend/utils.py`, making it straightforward to add new WCAG checks or expand color parsing.

---

## Example
Use `backend/test_sample.html` (the one from your prompt). Paste it into the UI and click **Submit**. You should see:
- `COLOR_CONTRAST` violation on `<h1>`
- `DOC_LANG_MISSING` on `<html>`
- `IMG_ALT_MISSING` on `<img>`
- `LINK_GENERIC_TEXT` on `<a>`

Click a result and watch the preview scroll and highlight the exact node.

---

## Production Tips
- Lock down CORS and add rate limiting
- Sanitize or fully sandbox user‑supplied HTML when rendering previews
- Consider server‑side extraction of computed styles with a headless browser for more accurate contrast checks
- Add unit tests for each rule and snapshot tests for selectors
- Dockerize both services and add a single `docker-compose.yml`

Enjoy!
