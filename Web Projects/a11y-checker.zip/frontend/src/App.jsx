import React, { useEffect, useRef, useState } from "react"
import { analyzeHtml } from "./api"

const SAMPLE_HTML = `<html lang="">
<head>
<title>Page</title>
</head>
<body>
<h1 style="color: lightgreen;
background-color: green;">Welcome</h1>
<h3>Our Services</h3>
<img src="/logo.png" alt="">
<p>To learn more about our
offerings, <a href="/more">click
here</a>.</p>
</body>
</html>`

export default function App() {
  const [html, setHtml] = useState(() => localStorage.getItem("a11y_html") || SAMPLE_HTML)
  const [apiBase, setApiBase] = useState("http://localhost:8000")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [results, setResults] = useState([])
  const iframeRef = useRef(null)

  useEffect(() => {
    localStorage.setItem("a11y_html", html)
  }, [html])

  const onUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    const text = await file.text()
    setHtml(text)
    e.target.value = ""
  }

  const onAnalyze = async () => {
    setLoading(true); setError(""); setResults([])
    try {
      const { violations } = await analyzeHtml(html, apiBase)
      setResults(violations)
      // load preview
      const iframe = iframeRef.current
      if (iframe) {
        const highlightCss = `
          <style>
            .a11y-highlight { outline: 3px solid #ff1a1a !important; background-color: rgba(255,255,0,.25) !important; }
          </style>`
        const listenerScript = `
          <script>
            window.addEventListener('message', (evt) => {
              try {
                if (evt.data && evt.data.type === 'HIGHLIGHT' && evt.data.selector) {
                  const el = document.querySelector(evt.data.selector)
                  if (el) {
                    document.querySelectorAll('.a11y-highlight').forEach(n => n.classList.remove('a11y-highlight'))
                    el.classList.add('a11y-highlight')
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
                  }
                }
              } catch (e) { /* ignore */ }
            })
          </script>`
        iframe.srcdoc = html.replace("</head>", `${highlightCss}${listenerScript}</head>`)
      }
    } catch (err) {
      setError(err.message || String(err))
    } finally {
      setLoading(false)
    }
  }

  const onClickItem = (sel) => {
    const iframe = iframeRef.current
    if (!iframe?.contentWindow) return
    iframe.contentWindow.postMessage({ type: "HIGHLIGHT", selector: sel }, "*")
    navigator.clipboard?.writeText(sel).catch(() => {})
  }

  return (
    <>
      <header><h1>HTML Accessibility Checker</h1></header>
      <div className="container">
        <div className="panel">
          <h2>Input HTML</h2>
          <textarea value={html} onChange={(e) => setHtml(e.target.value)} spellCheck={false} />
          <div className="controls">
            <label className="label-file">
              Upload .html
              <input type="file" accept=".html,.htm,.txt" onChange={onUpload} />
            </label>
            <button className="primary" onClick={onAnalyze} disabled={loading}>{loading ? "Analyzing..." : "Submit"}</button>
            <span style={{marginLeft: "auto"}}>
              API: <input value={apiBase} onChange={e => setApiBase(e.target.value)} style={{width:"220px"}} />
            </span>
          </div>
          {error && <p style={{color:"#b00020"}}><strong>Error:</strong> {error}</p>}
        </div>

        <div className="panel">
          <h2>Violations {results.length ? <span className="badge">{results.length}</span> : null}</h2>
          {results.length === 0 ? <p>No results yet. Paste HTML and click Submit.</p> : (
            <ul className="list">
              {results.map((v, i) => (
                <li key={i} className="item" onClick={() => onClickItem(v.selector)} title="Click to highlight & copy selector">
                  <div className="rule"><strong>{v.ruleId}</strong> — {v.element}</div>
                  <div>{v.message}</div>
                  <div><small className="mono">{v.selector}</small></div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="panel" style={{gridColumn: "1 / -1"}}>
          <h2>Preview</h2>
          <div className="preview-wrap">
            <iframe ref={iframeRef} title="HTML Preview" />
          </div>
        </div>
      </div>
      <footer>
        <small>Tip: Click a result to highlight the offending element in the preview and copy its CSS selector.</small>
      </footer>
    </>
  )
}
